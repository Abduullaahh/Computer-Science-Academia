#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>

char** Tokenize(char* command)
{
    int i, j, k, size = 0;
    for(i = 0; command[i] != '\0'; i++)
    {
        if(command[i] == ' ')
            size++;                                                // Total words calculation
    }
    size = size + 2;

    char** tokenized = malloc(size * sizeof(char*));

    j = 0;
    for(i = 0; i < size - 1; i++)
    {
        int len = 0;
        while (command[j] == ' ') j++;
        for(k = j; command[k] != ' ' && command[k] != '\0'; k++)
        {
            len++;                                                 // Calculating word length
        }
       
        tokenized[i] = malloc((len + 1) * sizeof(char));           // Coping command in token arr
       
        memcpy(tokenized[i], &command[j], len);
        tokenized[i][len] = '\0';
        j = k + 1;
    }
   
    tokenized[size - 1] = NULL;                                    // Last argument of execvp
   
    return tokenized;
}

int main()
{
	int status;
	double Elapsed_Time;
	char **token, command[100];
	struct timeval start_time, end_time;
	
	printf("> ");
	fgets(command, 100, stdin);
	command[strcspn(command, "\n")] = 0;
	
	token = Tokenize(command);
	
	pid_t pid = fork();
	if (pid < 0)
	{
		perror("fork failed");
		exit(1);
	}
	else if (pid == 0)
	{
		gettimeofday(&start_time, NULL);
		execvp(token[0], token);
		perror("execvp failed");
		exit(0);
	}
	else
	{
		wait(&status);
		gettimeofday(&end_time, NULL);
		Elapsed_Time = end_time.tv_sec - start_time.tv_sec;
		printf("Elapsed time: %.5f\n", Elapsed_Time);
	}
    return 0;
}