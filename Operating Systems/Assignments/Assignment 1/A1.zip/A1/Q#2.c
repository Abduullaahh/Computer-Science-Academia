#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int Collatz_Conjecture(int n)
{
	if(n % 2 == 0)
	{
		n = n / 2;
	}
	else
	{
		n = 3 * n + 1;
	}
	return n;
}

int main(int argc, char *argv[])
{
	int n;
    if(argc != 2)
	{
        printf("Invalid argument provided\n");
    }
	else
	{
		n = atoi(argv[1]);
		printf("Value of n : %d", n);
		
		while(n != 1)
		{
			int fd[2];
			if(pipe(fd) < 0)
			{
				perror("Pipe not created\n");
				exit(1);
			}
		
			pid_t pid = fork();
			if(pid < 0)
			{
				perror("Fork Failed");
				exit(1);
			}
			else if(pid == 0)
			{
				n = Collatz_Conjecture(n);
				printf("Value of n : %d", n);
				printf("\n");
				close(fd[0]);
				write(fd[1], &n, sizeof(n));
				close(fd[1]);
				exit(0);
			}
			else
			{
				close(fd[1]);
				wait(NULL);
				read(fd[0], &n, sizeof(n));
				close(fd[0]);
			}
		}
	}
	printf("Value of n : %d", n);
	return 0;
}